# Main menu
def main_list(params):
plugintools.log("albjb.main_list "+repr(params))

plugintools.add_item( 
	action="Disney", 
	title=plugintools.get_localized_string(T_OFFICIAL_WEBSITE) ,
	fanart="fanart.jpg",
	thumbnail="fanart.jpg",
	icon="icon.png",
	url="ftp://alb:666@albjb18.zapto.org:21/volume1/PELIS/Disney/" ,
	folder=True )

plugintools.add_item( 
	action="NEW", 
	title=plugintools.get_localized_string(T_OFFICIAL_WEBSITE) ,
	fanart="fanart.jpg",
	thumbnail="pelis.png",
	icon="icon.png",
	url="ftp://alb:666@albjb18.zapto.org:21/volume1/PELIS/NEW/" ,
	folder=True )
   
plugintools.add_item( action="search",
	title=plugintools.get_localized_string(T_SEARCH) )

plugintools.add_item( action="preferences",
	title=plugintools.get_localized_string(T_PREFERENCES),
	folder = False )
	
plugintools.set_view(plugintools.THUMBNAIL)
